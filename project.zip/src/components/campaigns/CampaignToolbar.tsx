"use client";

import { Plus } from "lucide-react";

import { Button } from "@/components/ui/button";

export default function CampaignToolbar() {
  return (
    <div className="flex items-center justify-end">
      <Button>
        <Plus className="mr-2 h-4 w-4" />
        New Campaign
      </Button>
    </div>
  );
}