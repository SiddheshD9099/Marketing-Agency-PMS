import { CalendarDays } from "lucide-react";
import Link from "next/link";
import { Campaign } from "@/types/database";
import { DashboardCard } from "@/components/ui/dashboard-card";
import { ProgressBar } from "@/components/ui/progress-bar";
import { StatusBadge } from "@/components/ui/status-badge";


interface CampaignCardProps {
  campaign: Campaign;
}

export default function CampaignCard({
  campaign,
}: CampaignCardProps) {
    return (
    <Link href={`/dashboard/campaigns/${campaign.id}`}>
        <DashboardCard className="cursor-pointer transition-all hover:scale-[1.02] hover:shadow-xl">
        <div className="space-y-5">
            <div className="flex items-start justify-between">
            <div>
                <h2 className="text-lg font-semibold">
                {campaign.campaign_name}
                </h2>

                <p className="text-sm text-muted-foreground">
                {campaign.client_name}
                </p>
            </div>

            <StatusBadge status={campaign.status} />
            </div>

            <ProgressBar value={campaign.progress} />

            <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <CalendarDays size={16} />

            <span>
                Due{" "}
                {new Date(campaign.deadline).toLocaleDateString("en-US", {
                day: "numeric",
                month: "short",
                year: "numeric",
                })}
            </span>
            </div>
        </div>
        </DashboardCard>
    </Link>
    );
}