import { Badge } from "@/components/ui/badge";
import { DashboardCard } from "@/components/ui/dashboard-card";
import { getAllTasks } from "@/lib/repositories/task.repository";

export default async function TasksPage() {
  const tasks = await getAllTasks();

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">
        Tasks
      </h1>

      {tasks.map((task: any) => (
        <DashboardCard key={task.id}>
          <div className="flex justify-between">
            <div>
              <h2 className="font-semibold">
                {task.title}
              </h2>

              <p className="text-sm text-muted-foreground">
                {task.campaign_name}
              </p>

              <p className="text-sm text-muted-foreground">
                {task.assignee_name}
              </p>
            </div>

            <div className="space-y-2 text-right">
              <Badge>
                {task.priority}
              </Badge>

              <Badge variant="secondary">
                {task.status}
              </Badge>
            </div>
          </div>
        </DashboardCard>
      ))}
    </div>
  );
}