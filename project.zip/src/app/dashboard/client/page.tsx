import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

import { getClientDashboard } from "@/lib/repositories/client.repository";

export default async function ClientDashboardPage() {
  const campaigns = await getClientDashboard();

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">
        Client Dashboard
      </h1>

      {campaigns.map((campaign: any) => (
        <div
          key={campaign.id}
          className="rounded-xl border bg-white p-6 shadow-sm"
        >
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold">
                {campaign.campaign_name}
              </h2>

              <p className="text-muted-foreground">
                {campaign.client_name}
              </p>
            </div>

            <Badge>
              {campaign.status}
            </Badge>
          </div>

          <div className="mt-6">
            <Progress value={campaign.progress} />
          </div>

          <div className="mt-6">
            <h3 className="mb-3 font-semibold">
              Upcoming Tasks
            </h3>

            <div className="space-y-2">
              {campaign.tasks.map((task: any) => (
                <div
                  key={task.id}
                  className="flex justify-between rounded-lg border p-3"
                >
                  <span>{task.title}</span>

                  <Badge variant="secondary">
                    {task.status}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}