import CampaignGrid from "@/components/campaigns/CampaignGrid";
import CampaignStats from "@/components/campaigns/CampaignStats";
import CampaignToolbar from "@/components/campaigns/CampaignToolbar";

import { SectionHeader } from "@/components/ui/section-header";

import { getCampaigns } from "@/lib/repositories/campaign.repository";

export default async function CampaignsPage() {
  const campaigns = await getCampaigns();

  return (
    <div className="space-y-8">

      <div className="flex items-center justify-between">

        <SectionHeader
          title="Campaigns"
          description="Manage all active marketing campaigns."
        />

        <CampaignToolbar />

      </div>

      <CampaignStats campaigns={campaigns} />

      <CampaignGrid campaigns={campaigns} />

    </div>
  );
}