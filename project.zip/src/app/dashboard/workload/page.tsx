import { Progress } from "@/components/ui/progress";
import { DashboardCard } from "@/components/ui/dashboard-card";
import { SectionHeader } from "@/components/ui/section-header";

import { getTeamWorkload } from "@/lib/repositories/user.repository";

export default async function WorkloadPage() {
  const users = await getTeamWorkload();

  return (
    <div className="space-y-8">
      <SectionHeader
        title="Team Workload"
        description="Current task distribution across the team."
      />

      <div className="grid gap-6 md:grid-cols-2">
        {users.map((user: any) => (
          <DashboardCard key={user.id}>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-semibold">
                    {user.full_name}
                  </h2>

                  <p className="text-sm text-muted-foreground">
                    {user.role}
                  </p>
                </div>

                <span className="rounded-full bg-slate-100 px-3 py-1 text-sm font-medium">
                  {user.taskCount}/{user.capacity}
                </span>
              </div>

              <Progress value={user.workload} />

              <p className="text-sm text-muted-foreground">
                {Math.round(user.workload)}% Utilized
              </p>
            </div>
          </DashboardCard>
        ))}
      </div>
    </div>
  );
}